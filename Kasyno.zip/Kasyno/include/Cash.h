#ifndef CASH_H
#define CASH_H


class Cash
{
    private:
    int money;

    public:
    Cash();
    int getMoney();
    void setMoney(int money);
    void random();
};

#endif // CASH_H
