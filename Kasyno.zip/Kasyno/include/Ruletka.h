#ifndef RULETKA_H
#define RULETKA_H

class Ruletka
{
    private:
        int liczba, wynik;
        int const min = 1, max = 36;
        int typgry;

    public:
        Ruletka();
        void roll();
};

#endif // RULETKA_H
