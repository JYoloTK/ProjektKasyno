#ifndef USER_H
#define USER_H

using namespace std;

class User
{
    private:
    string usn;
    int tm;

    public:
    User();


};

#endif // USER_H
