#ifndef MACHINE_H
#define MACHINE_H

#include "Cash.h"

class Machine: Cash
{
    private:
        int n1;
        int n2;
        int n3;

    public:
        Machine();
        void setn1(int n1);
        void setn2(int n2);
        void setn3(int n3);
        void los();
};

#endif // MACHINE_H
