#include <iostream>
#include <cstdlib>
#include <time.h>
#include <locale.h>
#include <string>

#include "Machine.h"
#include "Ruletka.h"
#include "Cash.h"
#include "User.h"

using namespace std;

void wyswietl_menu(){
    system("cls");
    cout << "----- MENU GŁÓWNE -----" << endl << endl;
    cout << "Wybierz akcję:" << endl;
    cout << "0. Wyjdź z kasyna" << endl;
    cout << "1. Zagraj w jednorękiego bandytę" << endl;
    cout << "2. Zagraj w ruletkę" << endl;
    cout << "3. Wylosuj stan konta :D" << endl;
    };


int main()
{
    setlocale(LC_CTYPE, "Polish");

    int wybor;
    wyswietl_menu();

    while(true){
        cin >> wybor;
        cout << endl;
        if(cin.good()){
            switch(wybor){
                case 0:{
                    cout << "Zapraszamy do ponownej gry :)" << endl;
                    return 0;
                    break;
                }
                case 1:{
                    Machine m;
                    m.los();
                    cout << endl;
                    cout << "Kliknij ENTER aby powrócić do głównego menu" << endl;
                    cin.ignore();
                    cin.get();
                    wyswietl_menu();
                    break;
                }
                case 2:{
                    Ruletka r;
                    r.roll();
                    cout << endl;
                    cout << "Kliknij ENTER aby powrócić do głównego menu" << endl;
                    cin.ignore();
                    cin.get();
                    wyswietl_menu();
                    break;
                }
                case 3:{
                    Cash c;
                    c.random();
                    cout << endl;
                    cout << "Kliknij ENTER aby powrócić do głównego menu" << endl;
                    cin.ignore();
                    cin.get();
                    wyswietl_menu();
                    break;
                }
                default:
                    cout << "Nie ma takiej akcji." << endl;
                    cout << "Kliknij ENTER aby powrócić do głównego menu" << endl;
                    cin.ignore();
                    cin.get();
                    wyswietl_menu();
                    break;
            }
            //system("cls");
        }else {
            cout << "Podałeś niepoprawnś wartość!" << endl << "Następuje zakończenie programu" << endl;
            break;
        }
    }

    return EXIT_SUCCESS;
}
