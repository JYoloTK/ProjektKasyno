#include <iostream>
#include <cstdlib>
#include <time.h>

#include "Cash.h"

using namespace std;

Cash::Cash(){
}

int Cash::getMoney(){
    return money;
}

void Cash::setMoney(int money){
    Cash::money = money;
}

void Cash::random(){
    srand(time(NULL));
    money = rand()%5+1;
    money = money * 5;
    Cash::setMoney(money);
    cout << Cash::getMoney() << " $" << endl;
}
