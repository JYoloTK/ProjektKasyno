#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>

#include "User.h"

using namespace std;

User::User(){
}


