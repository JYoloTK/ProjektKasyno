#include <iostream>
#include <cstdlib>
#include <time.h>

#include "Machine.h"

using namespace std;

Machine::Machine() : Cash(){
}

void Machine::setn1(int n1){
    Machine::n1 = n1;
}

void Machine::setn2(int n2){
    Machine::n2 = n2;
}

void Machine::setn3(int n3){
    Machine::n3 = n3;
}

void Machine::los(){
    srand(time(NULL));
    n1 = rand()%7+1;
    n2 = rand()%7+1;
    n3 = rand()%7+1;
    cout << n1 << " " << n2 << " " << n3 << endl;
    if(n1==n2 && n1==n3){
        cout << "Wygrałeś jackpot!!!" << endl;
    } else if(n1==n2 || n1==n3 || n2==n3){
        cout << "Wygrałeś" << endl;
        cout << Cash::getMoney()*2 << endl;
    } else{
        cout << "Przegrałeś" << endl;
        cout << Cash::getMoney() << endl;
    }
}


