#include <iostream>
#include <cstdlib>
#include <time.h>

#include "Ruletka.h"

using namespace std;

Ruletka::Ruletka(){
}

void Ruletka::roll(){
    cout << "Wybierz na co stawiasz:" << endl;
    cout << "1. Konkretna liczba" << endl;
    cout << "2. Parzyste/nieparzyste" << endl;
    cin >> typgry;
    cout << endl;
    if(cin.good()){
        if(typgry==1){
            cout << "Wpisz liczbę na którą stawiasz (z przedziału 1-36): " << endl;
            cin >> liczba;
            cout << endl;
            if(cin.good()){
                srand(time(NULL));
                wynik = rand() % (max - min + 1) + min;
                cout << "Kulka wylądowała na " << wynik << endl;
                if(liczba!=wynik){
                    cout << "Przegrałeś" << endl;
                } else if(liczba==wynik){
                    cout << "Wygrałeś!!!" << endl;
                }
            }else{
                cout << " " << endl;
            }
        } else if(typgry==2){
            cout << "Wybierz opcję:" << endl;
            cout << "1. Stawiam na parzyste" << endl;
            cout << "2. Stawiam na nieparzyste" << endl;
            cin >> liczba;
            cout << endl;
            if(cin.good()){
                if(liczba==1){
                    cout << "Obstawiłeś liczby parzyste" << endl;
                    srand(time(NULL));
                    wynik = rand() % (max - min + 1) + min;
                    cout << "Kulka wylądowała na " << wynik << endl;
                    if(2*(wynik/2) == wynik){
                        cout << "Wygrałeś!" << endl;
                    }else cout << "Przegrałeś" << endl;
                } else if (liczba==2){
                    cout << "Obstawiłeś liczby nieparzyste" << endl;
                    srand(time(NULL));
                    wynik = rand() % (max - min + 1) + min;
                    cout << "Kulka wylądowała na " << wynik << endl;
                    if(2*(wynik/2) == wynik){
                        cout << "Przegrałeś" << endl;
                    }else cout << "Wygrałeś!" << endl;
                } else if(liczba!=1 || liczba!=2){
                    cout << "Wybierz spośród dostępnych opcji" << endl;
                }
            }else{
                cout << " " << endl;
            }
        } else if(typgry!=1 || typgry!=2){
            cout << "Wybierz spośród dostępnych opcji" << endl;
        }
    }else{
        cout << " " << endl;
    }
}

